/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     29/09/2019 12:31:52 p.m.                     */
/*==============================================================*/


drop table if exists CLIENTE;

drop table if exists COMPRA;

drop table if exists DETCOMPRA;

drop table if exists DETVENTA;

drop table if exists FARMACEUTICO;

drop table if exists MARCA;

drop table if exists MEDICAMENTO;

drop table if exists PERSONA;

drop table if exists PROVEEDOR;

drop table if exists TELEFONO;

drop table if exists VENTA;

/*==============================================================*/
/* Table: CLIENTE                                               */
/*==============================================================*/
create table CLIENTE
(
   CI                   int not null,
   CODCLI               int not null,
   primary key (CI, CODCLI)
);

/*==============================================================*/
/* Table: COMPRA                                                */
/*==============================================================*/
create table COMPRA
(
   CI                   int not null,
   CODPROV              int not null,
   FAR_CI               int not null,
   CODFARMA             int not null,
   CODCOMPRA            int not null,
   TOTAL                int not null,
   primary key (FAR_CI, CI, CODPROV, CODFARMA, CODCOMPRA)
);

/*==============================================================*/
/* Table: DETCOMPRA                                             */
/*==============================================================*/
create table DETCOMPRA
(
   FAR_CI               int not null,
   CI                   int not null,
   CODFARMA             int not null,
   CODCLI               int not null,
   CODVENTA_            int not null,
   CODMED               int not null,
   CANT                 int not null,
   SUBTOTAL             int not null,
   primary key (FAR_CI, CI, CODFARMA, CODCLI, CODVENTA_, CODMED)
);

/*==============================================================*/
/* Table: DETVENTA                                              */
/*==============================================================*/
create table DETVENTA
(
   FAR_CI               int not null,
   CI                   int not null,
   CODPROV              int not null,
   CODFARMA             int not null,
   CODCOMPRA            int not null,
   CODMED               int not null,
   CANTP                int not null,
   SUBTOTALP            int not null,
   primary key (FAR_CI, CI, CODPROV, CODFARMA, CODCOMPRA, CODMED)
);

/*==============================================================*/
/* Table: FARMACEUTICO                                          */
/*==============================================================*/
create table FARMACEUTICO
(
   CI                   int not null,
   CODFARMA             int not null,
   primary key (CI, CODFARMA)
);

/*==============================================================*/
/* Table: MARCA                                                 */
/*==============================================================*/
create table MARCA
(
   CODMARCA             int not null,
   NOMBREMARCA          char(20) not null,
   primary key (CODMARCA)
);

/*==============================================================*/
/* Table: MEDICAMENTO                                           */
/*==============================================================*/
create table MEDICAMENTO
(
   CODMED               int not null,
   CODMARCA             int,
   NOMBRE               char(20) not null,
   primary key (CODMED)
);

/*==============================================================*/
/* Table: PERSONA                                               */
/*==============================================================*/
create table PERSONA
(
   CI                   int not null,
   FAR_CI               int,
   CODFARMA             int,
   PRO_CI               int,
   CODPROV              int,
   CLI_CI               int,
   CODCLI               int,
   NOMBRE               char(20) not null,
   FECHANAC             date not null,
   primary key (CI)
);

/*==============================================================*/
/* Table: PROVEEDOR                                             */
/*==============================================================*/
create table PROVEEDOR
(
   CI                   int not null,
   CODPROV              int not null,
   primary key (CI, CODPROV)
);

/*==============================================================*/
/* Table: TELEFONO                                              */
/*==============================================================*/
create table TELEFONO
(
   CI                   int not null,
   CODNUMERO            int not null,
   NUMERO               int not null,
   primary key (CI, CODNUMERO)
);

/*==============================================================*/
/* Table: VENTA                                                 */
/*==============================================================*/
create table VENTA
(
   FAR_CI               int not null,
   CODFARMA             int not null,
   CI                   int not null,
   CODCLI               int not null,
   CODVENTA_            int not null,
   TOTAL                int not null,
   primary key (FAR_CI, CI, CODFARMA, CODCLI, CODVENTA_)
);

alter table CLIENTE add constraint FK_ESCLI2 foreign key (CI)
      references PERSONA (CI) on delete restrict on update restrict;

alter table COMPRA add constraint FK_FARM_COMP foreign key (FAR_CI, CODFARMA)
      references FARMACEUTICO (CI, CODFARMA) on delete restrict on update restrict;

alter table COMPRA add constraint FK_PRO_COM foreign key (CI, CODPROV)
      references PROVEEDOR (CI, CODPROV) on delete restrict on update restrict;

alter table DETCOMPRA add constraint FK_DETC_MED foreign key (CODMED)
      references MEDICAMENTO (CODMED) on delete restrict on update restrict;

alter table DETCOMPRA add constraint FK_VEN_DETC foreign key (FAR_CI, CI, CODFARMA, CODCLI, CODVENTA_)
      references VENTA (FAR_CI, CI, CODFARMA, CODCLI, CODVENTA_) on delete restrict on update restrict;

alter table DETVENTA add constraint FK_COM_DETV foreign key (FAR_CI, CI, CODPROV, CODFARMA, CODCOMPRA)
      references COMPRA (FAR_CI, CI, CODPROV, CODFARMA, CODCOMPRA) on delete restrict on update restrict;

alter table DETVENTA add constraint FK_MED_DETV foreign key (CODMED)
      references MEDICAMENTO (CODMED) on delete restrict on update restrict;

alter table FARMACEUTICO add constraint FK_ESFARM2 foreign key (CI)
      references PERSONA (CI) on delete restrict on update restrict;

alter table MEDICAMENTO add constraint FK_TIENEMAR foreign key (CODMARCA)
      references MARCA (CODMARCA) on delete restrict on update restrict;

alter table PERSONA add constraint FK_ESCLI foreign key (CLI_CI, CODCLI)
      references CLIENTE (CI, CODCLI) on delete restrict on update restrict;

alter table PERSONA add constraint FK_ESFARM foreign key (FAR_CI, CODFARMA)
      references FARMACEUTICO (CI, CODFARMA) on delete restrict on update restrict;

alter table PERSONA add constraint FK_ESPROV foreign key (PRO_CI, CODPROV)
      references PROVEEDOR (CI, CODPROV) on delete restrict on update restrict;

alter table PROVEEDOR add constraint FK_ESPROV2 foreign key (CI)
      references PERSONA (CI) on delete restrict on update restrict;

alter table TELEFONO add constraint FK_TIENETEL foreign key (CI)
      references PERSONA (CI) on delete restrict on update restrict;

alter table VENTA add constraint FK_CLI_VEN foreign key (CI, CODCLI)
      references CLIENTE (CI, CODCLI) on delete restrict on update restrict;

alter table VENTA add constraint FK_FARM_VEN foreign key (FAR_CI, CODFARMA)
      references FARMACEUTICO (CI, CODFARMA) on delete restrict on update restrict;

